<?php
/**
 * Plugin Name: Показать путь к шаблону / Template Debug  
 * Description: Показывает путь к текущему шаблону на фронтенде (только для авторизованных пользователей). Можно включить/выключить через настройки. В меню «Настройки» появится пункт Template Debug , где можно включать/выключать отображение.
 * Version: 1.0
 * Author: https://github.com/kosmos1you/Template-Debug
 */

// Добавляем пункт меню в админку
add_action('admin_menu', 'tdv_add_admin_menu');
add_action('admin_init', 'tdv_register_settings');

function tdv_add_admin_menu() {
    add_options_page(
        'Template Debug',     // Заголовок страницы
        'Template Debug',     // Название в меню
        'manage_options',            // Право доступа
        'template-debug-viewer',     // Слаг
        'tdv_settings_page'          // Callback для рендера
    );
}

function tdv_register_settings() {
    register_setting('tdv_settings_group', 'tdv_enabled');
}

function tdv_settings_page() {
    ?>
    <div class="wrap">
        <h1>Показать путь к шаблону (Template Debug)</h1>
        <form method="post" action="options.php">
            <?php settings_fields('tdv_settings_group'); ?>
            <?php do_settings_sections('tdv_settings_group'); ?>

            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Включить показ шаблона</th>
                    <td>
                        <input type="checkbox" name="tdv_enabled" value="1" <?php checked(1, get_option('tdv_enabled', 0)); ?> />
                        <label for="tdv_enabled"> Показывать полный путь к текущему шаблону (только авторизованным пользователям)</label>
                    </td>
                </tr>
            </table>

            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Функция для показа шаблона внизу страницы
add_action('wp_footer', 'tdv_show_template');
function tdv_show_template() {
    if (is_user_logged_in() && get_option('tdv_enabled', 0)) {
        global $template;
        echo '<div style="position:fixed;bottom:50px;right:10px;background:red;color:white;padding:10px;z-index:99999999;font-family:monospace;max-width:80%;word-break:break-all;">';
        echo 'Template: ' . esc_html($template);
        echo '</div>';
    }
}
